<?php 
/*
Plugin Name:Cool Author Box
Plugin URI: http://www.smartwebtricks.com
Description: This is Cool Author Box Plugin
Version: 1.0
Author: Usama Noman
Author URI: http://www.smartwebtricks.com
*/
 
function perform_function($attr)
{
print_r($attr);
/*	*/
} 
 
add_shortcode("AUTHOR",function($attr){
if(!isset($attr['bg'])) $bg="white";
else $bg=$attr['bg'];
if(!isset($attr['font'])) $font="black";
else $font=$attr['font'];


	$author_name=get_the_author();
	$author_bio=get_the_author_meta('description');
	$gravatar=get_avatar( get_the_author_meta('email') , 90 );
	return "<div style='color:$font;background-color:$bg;border:2px solid gray;border-radius:10px 10px 10px 10px; height:200px'>
			<div style='padding-bottom:-10px; padding-top:-25px; padding-left:20px;'>
					<h2 >About $author_name</h2>
			</div>
			<hr>
			<div>
			<div style='float:left; padding-left:10px;padding-right:10px;'>$gravatar</div>
			<p style=''>$author_bio</p>
			</div>
			</div>";


}

);
 
 ?>